import { LegalPage } from './LegalPage';

export function Privacy() {
  return <LegalPage title="Privacy Policy" updated="January 2026" sections={[
    { heading: 'Information We Collect', body: 'We collect information you provide directly to us — such as your name, email, shipping address, and payment details when you create an account or place an order. We also automatically collect usage data including device information, IP address, and browsing behavior through cookies and similar technologies.' },
    { heading: 'How We Use Your Information', body: 'We use your information to process orders, communicate with you about your account and orders, provide customer support, personalize your experience, send marketing communications (with your consent), and comply with legal obligations.' },
    { heading: 'Information Sharing', body: 'We do not sell your personal information. We may share data with trusted service providers who help us operate our business (payment processors, shipping carriers, email providers), all bound by strict confidentiality obligations. We may disclose information when required by law.' },
    { heading: 'Data Security', body: 'We implement industry-standard security measures including SSL encryption, secure data storage, and regular security audits. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.' },
    { heading: 'Your Rights', body: 'You have the right to access, correct, or delete your personal data. You may also opt out of marketing communications at any time. To exercise these rights, contact us at privacy@luxe.co.' },
    { heading: 'Age Verification', body: 'As a retailer of age-restricted products, we verify the age of our customers. We may use third-party age verification services and retain verification records as required by law.' },
    { heading: 'Cookies', body: 'We use cookies to enhance your browsing experience, analyze traffic, and remember your preferences. See our Cookie Policy for details. You can control cookies through your browser settings.' },
  ]} />;
}

export function Terms() {
  return <LegalPage title="Terms of Service" updated="January 2026" sections={[
    { heading: 'Acceptance of Terms', body: 'By accessing or using LUXE, you agree to be bound by these Terms of Service. If you do not agree, please do not use our website or services.' },
    { heading: 'Eligibility', body: 'You must be at least 21 years of age (or the legal smoking age in your jurisdiction) to use our services. By placing an order, you confirm you meet this requirement. We may verify your age at any time.' },
    { heading: 'Products & Nicotine Warning', body: 'Our products contain nicotine, a highly addictive chemical. Products are not intended for use by minors, pregnant or breastfeeding women, or individuals with medical conditions. Consult a physician before use.' },
    { heading: 'Orders & Payment', body: 'All orders are subject to acceptance and availability. We reserve the right to refuse or cancel any order. Prices are subject to change without notice. Payment is processed at the time of order confirmation.' },
    { heading: 'Shipping & Returns', body: 'We ship to addresses within the United States. Shipping times are estimates and not guaranteed. Returns are accepted within 30 days of delivery for unopened products in original packaging. See our return policy for details.' },
    { heading: 'Intellectual Property', body: 'All content on this site — including text, graphics, logos, and images — is the property of LUXE or its licensors and is protected by copyright and trademark laws. You may not reproduce or distribute without permission.' },
    { heading: 'Limitation of Liability', body: 'LUXE is not liable for any indirect, incidental, or consequential damages arising from the use of our products or services. Our total liability is limited to the amount you paid for the product in question.' },
    { heading: 'Changes to Terms', body: 'We may update these terms at any time. Continued use of our services after changes constitutes acceptance of the updated terms.' },
  ]} />;
}

export function Cookies() {
  return <LegalPage title="Cookie Policy" updated="January 2026" sections={[
    { heading: 'What Are Cookies', body: 'Cookies are small text files stored on your device when you visit a website. They help us remember your preferences, analyze traffic, and provide a better experience.' },
    { heading: 'Types of Cookies We Use', body: 'Essential cookies: required for the site to function (login, cart, security).\nAnalytical cookies: help us understand how visitors use our site.\nFunctional cookies: remember your preferences like language and region.\nMarketing cookies: used to show relevant ads on other platforms.' },
    { heading: 'Managing Cookies', body: 'You can control or delete cookies through your browser settings. Disabling cookies may affect site functionality — for example, you may not be able to stay logged in or keep items in your cart.' },
    { heading: 'Third-Party Cookies', body: 'We use third-party services (analytics, advertising) that may set their own cookies. These are governed by their respective privacy policies.' },
    { heading: 'Your Consent', body: 'By using our website, you consent to the use of cookies as described in this policy. You can withdraw consent at any time by clearing your browser cookies.' },
  ]} />;
}
